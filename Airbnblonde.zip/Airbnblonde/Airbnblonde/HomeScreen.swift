//
//  HomeScreen.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/22/23.
//

import SwiftUI

struct HomeScreen: View {
    @State private var showDestinationHouseSearchView = false
    @StateObject var viewModel = HomeScreenViewModel(service: HomeService())
    var body: some View {
        NavigationStack{
            Image("logo")
                .resizable()
                .scaledToFill()
                .frame(width: 250, height: 100)
            
            if showDestinationHouseSearchView{
                DestinationHouseSearchView(show: $showDestinationHouseSearchView, viewModel: viewModel)
            }
            else {
                ScrollView{
                    SearchFilterBar(location: $viewModel.searchLocaiton)
                        .onTapGesture {
                            withAnimation(.snappy){
                                showDestinationHouseSearchView.toggle()
                            }
                        }
                    LazyVStack (spacing:32){
                   
                        ForEach(viewModel.listings) {
                            listing in
                            NavigationLink(value: listing) {
                                listingView(listing: listing)
                                    .frame(height: 320)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }
                    .padding()
                }
                
                .navigationDestination(for: Listing.self){
                    listing in
                    HouseDetailView(listing: listing)
                        .navigationBarBackButtonHidden()
                }
            }
        }
    }
}
            
            
       
    #Preview {
        HomeScreen()
    }

