//
//  SignInEmailView.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/7/23.
//

import SwiftUI
@MainActor
final class SignInEmailViewModel: ObservableObject{
    @Published var email = ""
    @Published var password = ""
    func signUp() async throws {
        guard !email.isEmpty, !password.isEmpty else {
            print("No Email OR Password found.")
            return
        }
            try await AuthenticationManager.shared.createUser(email: email, password: password)
        }
    func signIn() async throws {
        guard !email.isEmpty, !password.isEmpty else {
            print("No Email OR Password found.")
            return
        }
            try await AuthenticationManager.shared.signInUser(email: email, password: password)
        }
}

struct SignInEmailView: View {
    @StateObject private var viewModel = SignInEmailViewModel()
    @Binding var showSignInView: Bool
    var body: some View {
        VStack{
            Image("logo")
                .resizable()
                .scaledToFill()
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 120)
            
            VStack{
                TextField("Email...", text: $viewModel.email)
                    .padding()
                    .background(Color.gray.opacity(0.4))
                    .cornerRadius(10)
                
                SecureField("Password...", text: $viewModel.password)
                    .padding()
                    .background(Color.gray.opacity(0.4))
                    .cornerRadius(10)
                
                Button {
                    Task{
                        do{
                            try await viewModel.signUp()
                            showSignInView = false
                            return
                        } catch {
                            print(error)
                        }
                    }
                    } label: {
                        Text("Sign Up")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(height:55)
                            .frame(width:350)
                            .background(Color.blue)
                            .cornerRadius(10)
                }
                Button {
                    Task{
                        do{
                            try await viewModel.signIn()
                            showSignInView = false
                            return
                        } catch {
                            print(error)
                        }
                    }
                    } label: {
                        Text("Sign In")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(height:55)
                            .frame(width: 350)
                            .background(Color.blue)
                            .cornerRadius(10)
                }
            }
            .padding()
            .navigationTitle("Sign in with Email")
        }
    }
}
    struct SignInView_Previews: PreviewProvider {
        static var previews: some View{
            SignInEmailView(showSignInView: .constant(false))
        }
}
