import UIKit
import SwiftUI
import MessageUI
@MainActor

final class SettingsViewModel: ObservableObject {
    
    func signOut () throws {
        try AuthenticationManager.shared.signOut()
    }
    func resetPassowrd() async throws {
        let authUser = try AuthenticationManager.shared.getAuthenticatedUser()
        guard let email = authUser.email else {
            throw URLError(.fileDoesNotExist)
        }
        try await AuthenticationManager.shared.resetPassword(email: email)
    }
    func updateEmail() async throws {
        let email = "hell0123@gmail.com"
        try await AuthenticationManager.shared.updateEmail(email: email)
        
    }
}
struct SettingsView: View {
    @StateObject private var viewModel = SettingsViewModel()
    @Binding var showSignInView: Bool
    var body: some View {
        List{
            Button ("Sign Out") {
                Task {
                    do {
                        try viewModel.signOut()
                        showSignInView = true
                    } catch {
                        print (error)
                    }
                }
            }
                emailSection
        }
            .navigationTitle("Settings")
        }
    }

struct SettingsView_Previews: PreviewProvider{
    static var previews: some View {
        NavigationStack{
            SettingsView(showSignInView: .constant(false))
        }
    }
}
extension SettingsView {
    private var emailSection: some View {
        Section {
            Button ("Reset Password") {
                Task {
                    do {
                        try await viewModel.resetPassowrd()
                        print ("Password reset.")
                    } catch {
                        print (error)
                    }
                }
                
            }
            Button ("Update Email") {
                Task {
                    do {
                        try await viewModel.updateEmail( )
                        print ("Email Updated.")
                    } catch {
                        print (error)
                    }
                }
                
            }

        } header: {
            Text ("Email Functions")
        }
    }
  
    }

