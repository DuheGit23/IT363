//
//  Wednesday.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/22/23.
//

import SwiftUI

struct listingView: View {
    let listing: Listing
    
    var body: some View {
        VStack(spacing: 8){
            ListingImageCarouseView(listing: listing)
            .frame(height: 320)
            .clipShape(RoundedRectangle(cornerRadius: 10))


            HStack (alignment: .top){
                VStack (alignment: .leading){
                    
                    Text("\(listing.houseTitle)")
                        .fontWeight(.bold)
                        .foregroundStyle(.black)
                         Text("\(listing.address)")
                        .foregroundStyle(.gray)
                         Text("\(listing.city), \(listing.state)")
                        .foregroundStyle(.gray)
                    HStack(spacing:2){
                        Text("\(listing.pricePerNight)")
                            .fontWeight(.semibold)
                        Text("/ Night")
                    }
                    
                }
                Spacer()
                HStack(spacing: 2){
                    Image(systemName: "star.fill")
                        .foregroundStyle(.black)
                        Text("\(listing.rating)")
                        .foregroundStyle(.black)
                }
                .font(.footnote)
            }
        }
    }
}
#Preview {
    listingView(listing: DeveloperPreview.shared.listings[0])
}
