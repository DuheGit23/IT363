//
//  AuthenticationView.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/7/23.
//

import SwiftUI
import GoogleSignIn
import GoogleSignInSwift


@MainActor
final class AuthenticationViewModel: ObservableObject {
    func signInGoogle() async throws {
    let helper = SignInGoogleHelper()
    let tokens = try await helper.signIn()
        try await AuthenticationManager.shared.signInWithGoogle(tokens: tokens)
    }
}
struct AuthenticationView: View {
    @StateObject private var viewModel = AuthenticationViewModel ()
    @Binding var showSignInView: Bool
  //  @State var selectedTab: Tabs = .home
    
    var body: some View {
        VStack{
            
            Image("logo")
                .resizable()
                .scaledToFill()
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 120)
            Spacer()
            
            NavigationLink{
                SignInEmailView(showSignInView: $showSignInView)
            
            } label: {
                Text("Sign In or Sign Up with Email")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(height:45)
                    .frame(maxWidth:.infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
                
            }
            GoogleSignInButton(viewModel: GoogleSignInButtonViewModel(scheme: .dark, style: .wide, state: .normal)){
                Task{
                    do {
                        try await viewModel.signInGoogle()
                        showSignInView = false
                    } catch {
                        print(error)
                    }
                }
            }
            
            Spacer()
     //       CustomTabBarView(selectedTab: $selectedTab)
     
        }
        .padding()
        
    }
}

struct AuthenticationView_Previews: PreviewProvider{
    static var previews: some View{
        NavigationStack{
            AuthenticationView(showSignInView: .constant(false))
        }
    }
}
