//
//  MapRegion.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import CoreLocation

extension CLLocationCoordinate2D {
    static var bloomington = CLLocationCoordinate2D(latitude: 40.5072272, longitude: -88.9119655)
    static var lincoln = CLLocationCoordinate2D(latitude: 40.1570656, longitude: -89.3707676)
    static var hudson = CLLocationCoordinate2D(latitude: 40.6521815,longitude: -89.9253683)
}
