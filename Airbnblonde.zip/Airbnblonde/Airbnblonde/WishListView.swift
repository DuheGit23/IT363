//
//  WishListView.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import SwiftUI
import GoogleSignIn
import GoogleSignInSwift


    @MainActor
    final class WishListViewModel: ObservableObject {
        func signInGoogle() async throws {
        let helper = SignInGoogleHelper()
        let tokens = try await helper.signIn()
            try await AuthenticationManager.shared.signInWithGoogle(tokens: tokens)
        }
    }
struct WishListView: View {
        @StateObject private var viewModel = AuthenticationViewModel ()
        @Binding var showSignInView: Bool

    var body: some View {
    NavigationStack{
        
        VStack (alignment: .leading, spacing: 30){
            VStack(alignment: .leading,spacing: 10){
                Text ("Log in to view your wishlists")
                    .font(.headline)
                Text("You can create, view or edit wishlists once you've logged")
                    .font(.footnote)
                
                NavigationLink{
                    SignInEmailView(showSignInView: $showSignInView)
                    
                } label: {
                    Text("Sign In or Sign Up with Email")
                        .padding()
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height:45)
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                    
                }
                
                GoogleSignInButton(viewModel: GoogleSignInButtonViewModel(scheme: .dark, style: .wide, state: .normal)){
                    Task{
                        do {
                            try await viewModel.signInGoogle()
                            showSignInView = false
                        } catch {
                            print(error)
                        }
                    }
                }
            }
            Spacer()
        }
        .padding()
        .navigationTitle("Wishlists")
        }
    }
}
struct WishListView_Previews: PreviewProvider{
    static var previews: some View{
        NavigationStack{
            WishListView(showSignInView: .constant(false))
        }
    }
}
