//
//  HomeScreenViewModel.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import Foundation
class HomeScreenViewModel: ObservableObject {
   
    @Published var listings = [Listing] ()
    @Published var searchLocaiton = ""
    private let service: HomeService
    private var searchListingsCopy = [Listing]()
    
    init(service: HomeService) {
        self.service = service
        Task{ await fetchListings() }
    }
    
    func fetchListings() async {
        do {
            self.listings = try await service.fetchListings()
            self.searchListingsCopy = listings
        } catch {
            print ("DEBUG: Failed to fetch listing with error: \(error.localizedDescription)")
        }
    }
    func updateListingsForLocation(){
        let filteredListings = listings.filter({
            $0.city.lowercased() == searchLocaiton.lowercased() ||
            $0.state.lowercased() == searchLocaiton.lowercased()
        })
        self.listings = filteredListings.isEmpty ? searchListingsCopy : filteredListings
    }
}
