//
//  ContentView.swift
//  Airbnblonde
//
//  Created by Jenny Lin  on 10/7/23.
//

import SwiftUI
struct ContentView: View {
    var body: some View {
        AirbnbTabView()
    }
}
#Preview {
    ContentView()
}
