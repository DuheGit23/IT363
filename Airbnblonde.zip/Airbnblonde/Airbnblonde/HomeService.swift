//
//  HomeService.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import Foundation
class HomeService {
    func fetchListings() async throws -> [Listing] {
        return DeveloperPreview.shared.listings
    }
}
