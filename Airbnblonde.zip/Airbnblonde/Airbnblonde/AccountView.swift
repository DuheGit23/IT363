//
//  AccountView.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import SwiftUI
import GoogleSignIn
import GoogleSignInSwift


    @MainActor
    final class AccountViewModel: ObservableObject {
        func signInGoogle() async throws {
        let helper = SignInGoogleHelper()
        let tokens = try await helper.signIn()
            try await AuthenticationManager.shared.signInWithGoogle(tokens: tokens)
        }
    }
struct AccountView: View {
        @StateObject private var viewModel = AuthenticationViewModel ()
        @Binding var showSignInView: Bool
    var body: some View {
        VStack {
            VStack (alignment: . leading, spacing: 20){
                VStack (alignment: . leading, spacing: 8){
                    Text("Profile")
                        .font(.largeTitle)
                    .fontWeight(.semibold)
                    Text("Log in to start planning your next trip")
                }

                NavigationLink{
                    SignInEmailView(showSignInView: $showSignInView)
                
                } label: {
                    Text("Sign In or Sign Up with Email")
                        .padding()
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height:45)
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                    
                }
                
                GoogleSignInButton(viewModel: GoogleSignInButtonViewModel(scheme: .dark, style: .wide, state: .normal)){
                    Task{
                        do {
                            try await viewModel.signInGoogle()
                            showSignInView = false
                        } catch {
                            print(error)
                        }
                    }
                }
            }
            
            VStack (spacing:24){
                ProfileOptionView(imageName: "gear", title: "Settings")
                ProfileOptionView(imageName: "gear", title: "Accessibility")
                ProfileOptionView(imageName: "questionmark.circle", title: "Vist the Help Center")
            }
            .padding(.vertical)
        }
        .padding()
    }

    
}

struct AccountView_Previews: PreviewProvider{
    static var previews: some View{
        NavigationStack{
            AccountView(showSignInView: .constant(false))
        }
    }
}
