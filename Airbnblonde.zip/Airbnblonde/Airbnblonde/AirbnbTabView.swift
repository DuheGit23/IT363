//
//  AirbnbTabView.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/22/23.
//

import SwiftUI

struct AirbnbTabView: View {
    var body: some View {
        TabView{
       

            HomeScreen()
                .tabItem { Image(systemName: "house")
                          Text ("Home")
                }
            WishListView(showSignInView: .constant(false))
                .tabItem { Image( systemName: "heart")
                          Text ("Wishlists")
                }
            ContactUs()
                .tabItem { Image(systemName: "text.bubble")
                           Text ("Message")
                }
            AuthenticationView(showSignInView: .constant(false))
                .tabItem{ Image(systemName: "person")
                          Text ("Account")
            }
            
        }
    }
}

#Preview {
    AirbnbTabView()
}
