//
//  ContactUs.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import SwiftUI

struct ContactUs: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ContactUs()
}
