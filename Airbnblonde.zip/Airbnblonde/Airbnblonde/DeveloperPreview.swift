//
//  DeveloperPreviw.swift
//  Airbnblonde
//
//  Created by Jenny Lin on 10/27/23.
//

import Foundation
class DeveloperPreview{
    static let shared = DeveloperPreview()
    var listings:[Listing] = [
        .init(id: NSUUID().uuidString,
              ownerUid: NSUUID().uuidString,
              ownerName: "Liz",
              numberOfBedrooms: 4,
              numberOfBethrooms: 5,
              numberOfGuests: 15,
              numberOfBeds: 6,
              pricePerNight: 549,
              latitude: 40.6521815,
              longitude: -89.9253683,
              imageURLs: ["LakeHouse", "Lakehouse lakeside View", "lakehouse deckview", "Lakehouse Guestroom view" , "Lakehouse Guestroom2", "Lakehouse Kids room", "Lakehouse MasterRoom" ,"Lakehouse Night view", "Lakehouse PoolView", "Lakehouse Theather", "Lakehouse Sunroom"],
              address: "18333 Kickapoo Lane",
              city: "Hudson",
              state: "IL",
              houseTitle: "Lake House",
              description: "Amazing views from everywhere. The upstairs features 3 large bedrooms and 2 full bathrooms, as well as a loft area with an air hockey table for the kids and a second loft area for with a futon. The main floor has a 3 seasons room, sprawling master with gas fireplace and a spa-like en suite bath that includes a steamer shower, tub, double vanity,and plenty of natural light! The walkout lower level has a bar, wine cellar, theater room, and more!",
              rating: 4.86,
              features: [.selfCheckIn, .superHost],
              amenities: [.pool, .wifi, .alarmSystem, .balcony, .laundry, .tv, .kitchen],
              type: .house
    ),
        .init( id: NSUUID().uuidString,
              ownerUid: NSUUID().uuidString,
              ownerName: "Liz",
              numberOfBedrooms: 2,
              numberOfBethrooms: 2,
              numberOfGuests: 6,
              numberOfBeds: 2,
              pricePerNight: 185,
               latitude: 40.1570656,
               longitude: -89.3707676,
               imageURLs: ["Wednesday", "wedkit", "wedliving","wed", "wedbed1","wedbed2"],
              address: "110 Edgar Street",
              city: "Lincoln",
              state: "IL",
              houseTitle: "Wendsday Lair",
               description: "This 1500 square foot home was originally built in 1993 but completely renovated to its current design in 2021. It is located on an expensive 1/2 acre lot with a large yard. The throwback octagon design from the 1800s purposefully has no square rooms.",
               rating: 4.9,
               features: [.selfCheckIn, .superHost],
               amenities: [.alarmSystem, .balcony, .kitchen, .laundry, .tv, .wifi],
              type: .house
              ),
        .init(id: NSUUID().uuidString,
              ownerUid: NSUUID().uuidString,
              ownerName: "Liz",
              numberOfBedrooms: 4,
              numberOfBethrooms: 6,
              numberOfGuests: 20,
              numberOfBeds: 6,
              pricePerNight: 599,
              latitude: 40.5072272,
              longitude: -88.9119655,
              imageURLs: ["TheMansion", "mansionBed1", "mansionBed2", "mansionBed3", "mansionBed4", "mansionLivingroom","mansionKitchen", "mansionBasement", "mansionGym", "MansionMainLivingRoom", "mansionMasterBathroom", "mansionBackYard"],
              address: "1 Worthington Court",
              city: "Bloomington",
              state: "IL",
              houseTitle: "The mansion of Bloomintong",
              description: "Exquisite home in Hawthorne Acres, sitting on a 1.2 acre professionally landscaped lot. Stunning two-story entry with a curved staircase. Deluxe crown molding and trim throughout. Bright living room with a vaulted ceiling, built-ins around the fireplace and an amazing wall of windows overlooking the beautiful patio and yard.",
              rating: 5,
              features: [.selfCheckIn, .superHost],
              amenities: [.alarmSystem, .balcony, .kitchen, .laundry, .tv, .wifi, .office],
              type: .house)
        ]
}
